---
name: explain-girr-move
description: Explain a move in FRTB SA GIRR delta capital between two dates. Use for daily or month-end capital explains.
---
1. Put both dates' sensitivities and official results in [inputs.json](./inputs.json) format.
2. Check what changed besides positions: params, units (MAR21.19), curve and tenor mapping.
3. Run [waterfall.py](./scripts/waterfall.py), one currency at a time. No hand arithmetic.
4. A date that doesn't reproduce: stop and fix it first. Show a scenario switch separately.
5. Write it up with [report.md](./report.md); name the tenors behind each move.
