"""Capital-move waterfall for FRTB SA GIRR delta.

Usage: python waterfall.py <inputs.json>

Reproduces both dates with our engine, then swaps one currency at a time
from t0 to t1 (alphabetical order) in the t0 binding scenario, and shows a
change of binding scenario as its own step. Prints a Markdown table for the
report. Contributions depend on the order; it is fixed so reports compare.
"""
import json
import sys

from frtb.sa.girr import SCENARIOS, girr_delta  # our engine: never re-implement MAR21 here


def eur(x, sign=False):
    return f"{x:+,.0f}" if sign else f"{x:,.0f}"


def flags(result):
    floored = {}
    for s in SCENARIOS:
        for b in result.floored[s]:
            floored.setdefault(b, []).append(s)
    out = [f"K_b floor: {b} ({', '.join(sc)})" for b, sc in floored.items()]
    alternative = [s for s in SCENARIOS if result.alternative_sb[s]]
    if alternative:
        out.append(f"alternative S_b ({', '.join(alternative)})")
    return "; ".join(out)


def main(path):
    with open(path, encoding="utf-8") as fh:
        d = json.load(fh)
    params, official, sens, tol = d["parameter_set"], d["official"], d["sensitivities"], d["tolerance"]
    if params["t0"] != params["t1"]:
        sys.exit(f"Stop: parameter sets differ ({params['t0']} vs {params['t1']}). Explain that change on its own first.")

    for date in ("t0", "t1"):
        ours = girr_delta(sens[date]).capital
        for s in SCENARIOS:
            if abs(ours[s] - official[date][s]) > tol:
                sys.exit(
                    f"Stop: {date} does not reproduce in {s} (ours {ours[s]:,.2f}, "
                    f"official {official[date][s]:,.2f}). Fix the inputs or the engine first."
                )

    b0, b1 = official["t0"]["binding"], official["t1"]["binding"]
    rows = list(sens["t0"])
    result = girr_delta(rows)
    start = previous = result.capital[b0]
    lines = [
        f"GIRR delta move for {d['desk']}, {d['dates']['t0']} to {d['dates']['t1']} (EUR, rounded)",
        "",
        f"Both dates reproduce within {tol:g}. Currency steps move the {b0} scenario, binding at t0.",
        "",
        "| Step | Change | Low | Medium | High | Move | Flags |",
        "|---|---|---|---|---|---|---|",
        f"| 0 | t0 sensitivities | {' | '.join(eur(result.capital[s]) for s in SCENARIOS)} | | {flags(result)} |",
    ]
    step = 0
    for ccy in sorted({r["currency"] for r in sens["t0"] + sens["t1"]}):
        old = [r for r in sens["t0"] if r["currency"] == ccy]
        new = [r for r in sens["t1"] if r["currency"] == ccy]
        if old == new:
            continue
        step += 1
        rows = [r for r in rows if r["currency"] != ccy] + new
        result = girr_delta(rows)
        value = result.capital[b0]
        lines.append(
            f"| {step} | {ccy} to t1 | {' | '.join(eur(result.capital[s]) for s in SCENARIOS)} "
            f"| {eur(value - previous, True)} | {flags(result)} |"
        )
        previous = value

    like_for_like = previous - start
    switch = result.capital[b1] - result.capital[b0]
    if b1 != b0:
        step += 1
        lines.append(f"| {step} | Binding scenario {b0} to {b1} | | | | {eur(switch, True)} | |")
    total = result.capital[b1] - start
    lines += [
        f"| | Total | | | | {eur(total, True)} | |",
        "",
        f"Like-for-like in {b0}: {eur(like_for_like, True)}. "
        + (f"Scenario switch to {b1}: {eur(switch, True)}. " if b1 != b0 else "No scenario switch. ")
        + f"Total: {eur(total, True)}.",
    ]
    print("\n".join(lines))


if __name__ == "__main__":
    main(sys.argv[1])
